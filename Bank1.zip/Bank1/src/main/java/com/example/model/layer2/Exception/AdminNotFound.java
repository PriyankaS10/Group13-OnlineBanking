package com.example.model.layer2.Exception;

public class AdminNotFound {

}
