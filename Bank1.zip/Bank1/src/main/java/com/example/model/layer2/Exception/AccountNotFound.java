package com.example.model.layer2.Exception;

public class AccountNotFound extends Exception {

	public AccountNotFound(String message) {
		super(message);
	}

	
}
