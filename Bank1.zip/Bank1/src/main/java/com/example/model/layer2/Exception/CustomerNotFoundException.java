package com.example.model.layer2.Exception;

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String str) {
		super(str);
	}
}