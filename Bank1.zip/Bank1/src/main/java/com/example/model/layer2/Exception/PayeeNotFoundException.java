package com.example.model.layer2.Exception;

public class PayeeNotFoundException extends Exception{
	
	public PayeeNotFoundException(String str) {
		super(str);
	}
	
}
