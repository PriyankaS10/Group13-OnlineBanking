export class Approvals{
    accounttype: string;
    createdon: string;
    custId:number;
    srn:number;
    
}