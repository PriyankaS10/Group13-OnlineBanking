export class Approval{
    approvalid:number;
    srn:number;
}