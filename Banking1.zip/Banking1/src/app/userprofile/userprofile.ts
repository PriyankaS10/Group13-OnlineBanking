export class userprofile{

    custid: number;
    dob: Date;
    email: String;
    fathername: String;
    firstname: String;
    lastname: String;
    middlename: String;
    mobilenumber: number; 
    city: String;
    landmark: String;
    line1: String;
    line2: String;
    pincode: number;
    state: String;
    title: String;
    aadharnumber: number;
}
    


