export class Transaction{

       transactionid: number;
        amounttransferred: number;
        modeoftransaction: String;
        remarks: String;
        transactiondate: any;
        toAccountNumber: number;
        fromAccountNumber: number;
}