export class Payee{

    //beneficiaryid:number;
    beneficiaryname:String;
    nickname:String;
    baccountnumber:number;
  


}