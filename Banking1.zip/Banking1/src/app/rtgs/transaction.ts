export class transaction{
    transactionid: number;
    amounttransferred: number;
    modeoftransaction: string;
    remarks: string;
    transactiondate: Date;
    fromAccountNumber: number;
    toAccountNumber: number;
}