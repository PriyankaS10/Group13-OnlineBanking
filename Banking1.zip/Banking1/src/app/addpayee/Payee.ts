export class Payee{

    beneficaryid:number;
    beneficiaryname:String;
    nickname:String;
    baccountnumber:number;


}